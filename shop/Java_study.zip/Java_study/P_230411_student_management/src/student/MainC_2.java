package student;

public class MainC_2 {
    String className = "";

    MainC_2(){
        this.className = "class";
    }
    MainC_2(String name){
        this.className = name;
    }
}