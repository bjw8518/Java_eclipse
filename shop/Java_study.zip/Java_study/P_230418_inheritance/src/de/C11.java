package de;

public class C11 {
    final static int Max_LENGTH = 100;
    final static int GAWI = 0;
    final static int BAWI = 1;
    final static int BO = 2;

    public static void likeFunction(){   //return값 없으면 void
        System.out.println(Max_LENGTH);
    }
    //접근 제한자🖐
    //private   :   단어 뜻 그대로 개인적인 것이라 외부에서 사용될 수 없도록 합니다.(상속받은곳에서 사용할수있게해줌)
    //public    :   단어 뜻 그대로 외부 클래스가 자유롭게 사용할 수 있도록 합니다.
    //protected :   은 패키지 또는 자식 클래스에서 사용할 수 있도록 합니다.


}
