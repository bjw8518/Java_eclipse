package com.kopo.c2;

public class C1 {
}
