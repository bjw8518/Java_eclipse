package defaultt;


public class ExClass4 {

    public static void main(String[] args) {
        int a = 10;
        a = a + 3;
//		a +=3; //a=a+3 //쓰지마러라
//		a =+ 3; //a에3을 넣어라 //쓰지마러라
        System.out.println(a);

        a++; //a = a + 1;같은내용
        a--; //a = a - 1;

        System.out.println(a);

    }

}
