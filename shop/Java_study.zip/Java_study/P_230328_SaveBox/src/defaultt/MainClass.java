package defaultt;

public class MainClass {
    public static void main(String[] args) {
        SaveBox s1 = new SaveBox();
        SaveBox s2 = new SaveBox();
        SaveBox s3 = new SaveBox();

//		s1.coin;
    }
}
