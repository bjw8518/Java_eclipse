package index;


public class Kaufu_jisu {
    public static void resultBmi() {


    }


}
