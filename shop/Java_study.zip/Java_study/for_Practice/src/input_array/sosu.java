//1부터 100까지의 수중에서 소수만 출력하세요
package input_array;

public class sosu {
    public static void main(String[] args) {

    }
}
