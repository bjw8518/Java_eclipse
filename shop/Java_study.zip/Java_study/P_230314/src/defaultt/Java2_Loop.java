package defaultt;

public class Java2_Loop {

    public static void main(String[] args) {
        /*
         * System.out.println("2 * 2 = "+ (2*2)); System.out.println("2 * 3 = "+ (2*3));
         * System.out.println("2 * 4 = "+ (2*4)); System.out.println("2 * 5 = "+ (2*5));
         * System.out.println("2 * 6 = "+ (2*6)); System.out.println("2 * 7 = "+ (2*7));
         * System.out.println("2 * 8 = "+ (2*8)); System.out.println("2 * 9 = "+ (2*9));
         */


        for(int i=2; i<10; i++) {
            System.out.println("2 * "+ i +" = " + (2*i));
        }
        System.out.println("=======");
        for(int i=1; i<10; i++) {
            System.out.println("3 * "+ i +" = " + (3*i));
        }
        System.out.println("=======");
        for(int i=1; i<10; i++) {
            System.out.println("4 * "+ i +" = " + (4*i));
        }
    }

}
