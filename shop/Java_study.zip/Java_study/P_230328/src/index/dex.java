package index;

import java.util.Scanner;

public class dex {

    public static void main(String[] args) {
        kaup kaup = new kaup(); //선언
        //double weight = kaup.inputWeight(); //double로 weight
        //double height = kaup.inputHeight();//double로 Height
        kaup.inputVar();
        kaup.cal();

    }

}