package rabbit;
import java.awt.*;
import java.io.FileInputStream;
import java.util.*;


public class main {

    public static void main(String[] args) throws Exception{
        System.setIn(new FileInputStream("rabbit/inputRabbit.txt"));
        Scanner sc = new Scanner(System.in);

        int [][]x = {};
        int result=0;



    }

}
