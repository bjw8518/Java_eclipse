package test;

public class ffo {
    public static void main(String[] args) {
        //1부터100까지 합구하기
        int sum = 0;
        for (int i = 0; i < 100; i++) {
            sum = sum + (i + 1);
        }
        System.out.println(sum);
    }
}
