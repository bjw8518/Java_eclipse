package com.kopo.c2;

public class C20 {
    public void testRun(){
        System.out.println("Test Run");
    }
}
