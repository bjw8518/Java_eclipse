package dododo;

public interface I2 {
    public void method3();
}
