package de;

public class Test2 {

    static int maxlength = 100;

    public static void likeFunction(){
        System.out.println(maxlength);
        maxlength++;
    }
}
