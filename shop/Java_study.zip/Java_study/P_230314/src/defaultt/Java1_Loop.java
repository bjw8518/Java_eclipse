package defaultt;


public class Java1_Loop {

    public static void main(String[] args) {

        int array[] = {-1,2,3,4,5}; //b는 ((( = {1,2,3,4,5})))얘를 가리킴





        System.out.println(array[0]);
        System.out.println(array[1]);
        System.out.println(array[2]);
        System.out.println(array[3]);
        System.out.println(array[4]);
        System.out.println("============");

        for(int i = 0; i<array.length; i++) {

            System.out.println(array[i]);
        }



        /*
         * String str[] = {"1","2","3","4","5"};
         * System.out.println(str[0]);
         */

        //반복문 for
        //int i = 0; // int 선언 시 에러 (지역변수) #dupicated
        //for (초기값; 종료조건; 증가분;){
        /*
         * for(int i = 0; i<=5; i++) { //i<=5(5를 포함한다), i<5 (5를 포함하지 않는다)
         * System.out.println(i); }
         */
        //
//		System.out.println(a);
//		a++;
//		//a +=1; // a = a + 1;
//		a += 1;
//		//a++ = a = a + 1; 같은내용
//		System.out.println(a);
    }

}
