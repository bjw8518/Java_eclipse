package defaultt;

public class star_3 {

    public static void main(String[] args) {

        for (int i = 0; i <= 5; i++) {
            for (int j = 0; j < 10-i; j++) {
                System.out.println("");
            }
            for(int j=0; j<i*2+1; j++) {
                System.out.println(i+1);
            }
            System.out.println();
        }
    }
}