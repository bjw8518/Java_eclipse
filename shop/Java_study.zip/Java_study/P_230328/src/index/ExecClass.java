package index;

import java.util.Scanner;

//교수님이 설명해주신내용****
//제로베이스부터 다시 만들수있을정도 아니면 교수님이 설명해주신 만큼만 이해하려고 노력!

public class ExecClass {

    public static void main(String[] args) {
        Sort sort = new Sort(); //new로 만들고 sort라는변수에 넣음
        sort.doSort();
        //sort.abc(); //sort에게 doSort하라고 시킴

        Scanner scanner = new Scanner(System.in);
    }

}
