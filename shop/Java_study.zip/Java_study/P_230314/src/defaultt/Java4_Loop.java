package defaultt;


public class Java4_Loop {

    public static void main(String[] args) {
        //1,2,3,4,5,6,7,8,9,10...100
        //i = 초기값 1, 종료값 100, 하나씩증가

        int sum = 0;

        for(int i = 1; i<=100; i++) {
            sum = sum + i;

        }
        System.out.println(sum);



    }

}
