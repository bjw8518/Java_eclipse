package index;

import java.util.Scanner;

public class egoong {

    public static void main(String[] args) {
//		int[][] arr = new int[3][3];
//		Scanner scanner = new Scanner(System.in);
//		System.out.println("숫자를 입력하세여");
//		for (int i = 0; i < 3; i++) {
//			for (int j = 0; j < 3; j++) {
//		}
    }

}
