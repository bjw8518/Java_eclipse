package defaultt;

import java.util.Scanner;

public class ExClass {

    public static void main(String[] args) {
        int a;
        a = 10;

        double b = 12.3;

        String c = "안녕";

        boolean d = false;

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);


        Scanner s = new Scanner(System.in);
        int next = s.nextInt();

    }

}
