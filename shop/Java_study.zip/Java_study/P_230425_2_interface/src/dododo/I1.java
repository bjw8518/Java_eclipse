package dododo;

public interface I1 {
    public void method1();
    public void method2();
}
