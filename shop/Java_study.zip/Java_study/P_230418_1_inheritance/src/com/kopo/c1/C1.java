package com.kopo.c1;

public class C1 {
    public void doPrint(){
        System.out.println("Hello");
    }
}
