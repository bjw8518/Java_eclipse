package defaultt;


public class star_1 {

    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) { 		//바깥의 for문(i)은 행(세로)
            for (int j = 0; j < i; j++) {	//(j)는 (i)에 +1씩
                System.out.print("*");
            }
            System.out.println();
        }

    }
}

